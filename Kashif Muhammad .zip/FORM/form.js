function Show() {
    var x = document.getElementById("submit").formtarget;
    
}